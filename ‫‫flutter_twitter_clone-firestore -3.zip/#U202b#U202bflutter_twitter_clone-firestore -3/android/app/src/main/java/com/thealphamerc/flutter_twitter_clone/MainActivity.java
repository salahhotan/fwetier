package com.thealphamerc.flutter_twitter_clone;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
